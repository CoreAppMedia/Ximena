//
//  Prueba.swift
//  AnimatedTabBar
//
//  Created by ximena juana mejia jacobo on 21/10/23.
//

import SwiftUI

struct Prueba: View {
    @Binding var showMenu: Bool
    var body: some View {
        Text("Hello, World!")
    }
}

#Preview {
    Base()
}
