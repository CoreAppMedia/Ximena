//
//  BoardingAnimationApp.swift
//  BoardingAnimation
//
//  Created by ximena juana mejia jacobo on 20/10/23.
//

import SwiftUI

@main
struct BoardingAnimationApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
