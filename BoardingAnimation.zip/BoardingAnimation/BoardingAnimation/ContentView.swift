//
//  ContentView.swift
//  BoardingAnimation
//
//  Created by ximena juana mejia jacobo on 20/10/23.
//

import SwiftUI

struct ContentView: View {
    var body: some View {
       
           Home()
        
    }
}

#Preview {
    ContentView()
}
