//
//  CrearCuestionario.swift
//  ProyectoChipil
//
//  Created by Oscar Valdes on 23/10/23.
//

import SwiftUI

struct CrearCuestionario: View {
    var body: some View {
        Text(/*@START_MENU_TOKEN@*/"Hello, World!"/*@END_MENU_TOKEN@*/)
    }
}

#Preview {
    CrearCuestionario()
}
