//
//  PhoneNumberApp.swift
//  PhoneNumber
//
//  Created by ximena juana mejia jacobo on 17/10/23.
//

import SwiftUI

@main
struct PhoneNumberApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
